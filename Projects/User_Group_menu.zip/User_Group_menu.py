import tkinter as tk
from tkinter import messagebox
import subprocess

def about():
    About_window = tk.Toplevel(root)
    About_window.title("About Program")
    
    scrollbar = tk.Scrollbar(About_window)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    
    text_box = tk.Text(About_window, wrap=tk.WORD, yscrollcommand=scrollbar.set)
    text_box.pack(expand=True, fill=tk.BOTH)
    
    # Replace the following with actual information about your program
    about_text = """
        |This program is a simple user and group management tool for Linux| 
        |  You can perform the following actions:                          |
        |                                                                  |
        |   1. Add User                                                    |
        |   2. Modify User                                                 |
        |   3. Delete User                                                 |
        |   4. List Users                                                  |
        |   5. Add Group                                                   |
        |   6. Modify Group                                                |
        |   7. Delete Group                                                |
        |   8. List Groups                                                 |
        |   9. Disable User                                                |
        |   10. Enable User                                                |
        |   11. Change Password                                            |
        |__________________________________________________________________|
        
    """
    
    text_box.insert(tk.END, about_text)
    
    scrollbar.config(command=text_box.yview)

    
def add_user(sudo_password):
    add_user_window = tk.Toplevel(root)
    add_user_window.title("Add User")
    
    label_username = tk.Label(add_user_window, text="Enter username:")
    label_username.grid(row=0, column=0, padx=10, pady=5)
    username_entry = tk.Entry(add_user_window)
    username_entry.grid(row=0, column=1, padx=10, pady=5)
    
    label_password = tk.Label(add_user_window, text="Enter password:")
    label_password.grid(row=1, column=0, padx=10, pady=5)
    password_entry = tk.Entry(add_user_window, show="*")
    password_entry.grid(row=1, column=1, padx=10, pady=5)
    
    button_add_user = tk.Button(add_user_window, text="Add User", command=lambda: add_user_action(username_entry.get(), password_entry.get(), sudo_password, add_user_window))
    button_add_user.grid(row=2, column=0, columnspan=2, padx=10, pady=5)

def add_user_action(username, password, sudo_password, add_user_window):
    if username and password:
        try:
            if sudo_password:
                sudo_command = f"echo '{sudo_password}' | sudo -S useradd -m -N -s /bin/bash {username}"
                subprocess.run(sudo_command, check=True, shell=True)
                subprocess.run(f"echo '{username}:{password}' | sudo -S chpasswd", check=True, shell=True)
            else:
                subprocess.run(['sudo', 'useradd', '-m', '-N', '-s', '/bin/bash', username], check=True)
                subprocess.run(['echo', f'{username}:{password}', '|', 'sudo', 'chpasswd'], check=True, shell=True)
            messagebox.showinfo("Success", f"User '{username}' added successfully.")
            add_user_window.destroy()
        except subprocess.CalledProcessError as e:
            messagebox.showerror("Error", f"Failed to add user: {e}")
    else:
        messagebox.showerror("Error", "Please enter both username and password.")

# Function to modify a user
def modify_user(old_username, new_username, sudo_password, modify_user_window):
    if old_username and new_username:
        try:
            if sudo_password:
                sudo_command = f"echo '{sudo_password}' | sudo -S usermod -l {new_username} -d /home/{new_username} -m {old_username}"
                subprocess.run(sudo_command, check=True, shell=True)
            else:
                subprocess.run(['sudo', 'usermod', '-l', new_username, '-d', f'/home/{new_username}', '-m', old_username], check=True)
            messagebox.showinfo("Success", f"User '{old_username}' modified to '{new_username}' successfully.")
            modify_user_window.destroy()
        except subprocess.CalledProcessError as e:
            messagebox.showerror("Error", f"Failed to modify user: {e}")
    else:
        messagebox.showerror("Error", "Please enter both old and new usernames.")

# Function to open modify user window
def open_modify_user_window(sudo_password):
    modify_user_window = tk.Toplevel(root)
    modify_user_window.title("Modify User")
    
    label_old_username = tk.Label(modify_user_window, text="Enter old username:")
    label_old_username.grid(row=0, column=0, padx=10, pady=5)
    old_username_entry = tk.Entry(modify_user_window)
    old_username_entry.grid(row=0, column=1, padx=10, pady=5)
    
    label_new_username = tk.Label(modify_user_window, text="Enter new username:")
    label_new_username.grid(row=1, column=0, padx=10, pady=5)
    new_username_entry = tk.Entry(modify_user_window)
    new_username_entry.grid(row=1, column=1, padx=10, pady=5)
    
    button_modify_user = tk.Button(modify_user_window, text="Modify User", command=lambda: modify_user(old_username_entry.get(), new_username_entry.get(), sudo_password, modify_user_window))
    button_modify_user.grid(row=2, column=0, columnspan=2, padx=10, pady=5)

# Function to open delete user window
def open_delete_user_window(sudo_password):
    delete_user_window = tk.Toplevel(root)
    delete_user_window.title("Delete User")
    
    label_username = tk.Label(delete_user_window, text="Enter username:")
    label_username.grid(row=0, column=0, padx=10, pady=5)
    
    username_entry = tk.Entry(delete_user_window)
    username_entry.grid(row=0, column=1, padx=10, pady=5)
    
    button_delete_user = tk.Button(delete_user_window, text="Delete User", command=lambda: delete_user(username_entry.get(), sudo_password))
    button_delete_user.grid(row=1, column=0, columnspan=2, padx=10, pady=5)

def delete_user(username, sudo_password):
    if not username:
        messagebox.showerror("Error", "Please enter a username.")
        return
    
    try:
        if sudo_password:
            sudo_command = f"echo '{sudo_password}' | sudo -S userdel -rf {username}"
            subprocess.run(sudo_command, check=True, shell=True)
        else:
            subprocess.run(['sudo', 'userdel', '-rf', username], check=True)
            
        messagebox.showinfo("Success", f"User '{username}' deleted successfully.")
    except subprocess.CalledProcessError as e:
        messagebox.showerror("Error", f"Failed to delete user: {e}")
    except Exception as e:
        messagebox.showerror("Error", f"An unexpected error occurred: {e}")

# Function to open list users window
def open_list_users_window():
    list_users_window = tk.Toplevel(root)
    list_users_window.title("List Users")
    scrollbar = tk.Scrollbar(list_users_window)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    text_box = tk.Text(list_users_window, wrap=tk.WORD, yscrollcommand=scrollbar.set)
    text_box.pack()
    scrollbar.config(command=text_box.yview)

    def get_usernames():
        usernames = []
        with open('/etc/passwd', 'r') as passwd_file:
            for line in passwd_file:
                username = line.split(':')[0]
                userid = line.split(':')[2]
                users_info = line.rstrip()
                usernames.append(f"Username: {username}\tUserID: {userid}\nUser Info: {users_info}\n{'=' * 40}\n")
        return usernames

    usernames = get_usernames()
    for user_info in usernames:
        text_box.insert(tk.END, user_info)

# Function to add a group
def add_group(sudo_password):
    add_group_window = tk.Toplevel(root)
    add_group_window.title("Add Group")
    
    label_groupname = tk.Label(add_group_window, text="Enter group name:")
    label_groupname.grid(row=0, column=0, padx=10, pady=5)
    groupname_entry = tk.Entry(add_group_window)
    groupname_entry.grid(row=0, column=1, padx=10, pady=5)
    
    button_add_group = tk.Button(add_group_window, text="Add Group", command=lambda: add_group_action(groupname_entry.get(), sudo_password, add_group_window))
    button_add_group.grid(row=1, column=0, columnspan=2, padx=10, pady=5)

def add_group_action(groupname, sudo_password, add_group_window):
    if groupname:
        try:
            if sudo_password:
                sudo_command = f"echo '{sudo_password}' | sudo -S groupadd {groupname}"
                subprocess.run(sudo_command, check=True, shell=True)
            else:
                subprocess.run(['sudo', 'groupadd', groupname], check=True)
            messagebox.showinfo("Success", f"Group '{groupname}' added successfully.")
            add_group_window.destroy()
        except subprocess.CalledProcessError as e:
            messagebox.showerror("Error", f"Failed to add group: {e}")
    else:
        messagebox.showerror("Error", "Please enter a group name.")

# Function to modify a group
def modify_group(sudo_password):
    modify_group_window = tk.Toplevel(root)
    modify_group_window.title("Modify Group")
    
    label_groupname = tk.Label(modify_group_window, text="Enter group name:")
    label_groupname.grid(row=0, column=0, padx=10, pady=5)
    groupname_entry = tk.Entry(modify_group_window)
    groupname_entry.grid(row=0, column=1, padx=10, pady=5)
    
    label_new_groupname = tk.Label(modify_group_window, text="Enter new group name:")
    label_new_groupname.grid(row=1, column=0, padx=10, pady=5)
    new_groupname_entry = tk.Entry(modify_group_window)
    new_groupname_entry.grid(row=1, column=1, padx=10, pady=5)
    
    button_modify_group = tk.Button(modify_group_window, text="Modify Group", command=lambda: modify_group_action(groupname_entry.get(), new_groupname_entry.get(), sudo_password, modify_group_window))
    button_modify_group.grid(row=2, column=0, columnspan=2, padx=10, pady=5)

def modify_group_action(groupname, new_groupname, sudo_password, modify_group_window):
    if groupname and new_groupname:
        try:
            if sudo_password:
                sudo_command = f"echo '{sudo_password}' | sudo -S groupmod -n {new_groupname} {groupname}"
                subprocess.run(sudo_command, check=True, shell=True)
            else:
                subprocess.run(['sudo', 'groupmod', '-n', new_groupname, groupname], check=True)
            messagebox.showinfo("Success", f"Group '{groupname}' modified to '{new_groupname}' successfully.")
            modify_group_window.destroy()
        except subprocess.CalledProcessError as e:
            messagebox.showerror("Error", f"Failed to modify group: {e}")
    else:
        messagebox.showerror("Error", "Please enter both group name and new group name.")

# Function to delete a group
def delete_group(sudo_password):
    delete_group_window = tk.Toplevel(root)
    delete_group_window.title("Delete Group")
    
    label_groupname = tk.Label(delete_group_window, text="Enter group name:")
    label_groupname.grid(row=0, column=0, padx=10, pady=5)
    groupname_entry = tk.Entry(delete_group_window)
    groupname_entry.grid(row=0, column=1, padx=10, pady=5)
    
    button_delete_group = tk.Button(delete_group_window, text="Delete Group", command=lambda: delete_group_action(groupname_entry.get(), sudo_password, delete_group_window))
    button_delete_group.grid(row=1, column=0, columnspan=2, padx=10, pady=5)

def delete_group_action(groupname, sudo_password, delete_group_window):
    if groupname:
        try:
            if sudo_password:
                sudo_command = f"echo '{sudo_password}' | sudo -S groupdel {groupname}"
                subprocess.run(sudo_command, check=True, shell=True)
            else:
                subprocess.run(['sudo', 'groupdel', groupname], check=True)
            messagebox.showinfo("Success", f"Group '{groupname}' deleted successfully.")
            delete_group_window.destroy()
        except subprocess.CalledProcessError as e:
            messagebox.showerror("Error", f"Failed to delete group: {e}")
    else:
        messagebox.showerror("Error", "Please enter a group name.")

# Function to open list groups window
def open_list_groups_window():
    list_groups_window = tk.Toplevel(root)
    list_groups_window.title("List Groups")
    scrollbar = tk.Scrollbar(list_groups_window)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    text_box = tk.Text(list_groups_window, wrap=tk.WORD, yscrollcommand=scrollbar.set)
    text_box.pack()
    scrollbar.config(command=text_box.yview)

    def get_groupnames():
        groupnames = []
        with open('/etc/group', 'r') as group_file:
            for line in group_file:
                groupname = line.split(':')[0]
                groupid = line.split(':')[2]
                groups_info = line.rstrip()
                groupnames.append(f"Groupname: {groupname}\tGroupID: {groupid}\nGroup Info: {groups_info}\n{'=' * 40}\n")
        return groupnames

    groupnames = get_groupnames()
    for group_info in groupnames:
        text_box.insert(tk.END, group_info)

# Function to disable a user account
def dis(sudo_password):
    disable_user_window = tk.Toplevel(root)
    disable_user_window.title("disable User")
    # Adjust window size
    disable_user_window.geometry('500x200') 
    username = tk.Entry(disable_user_window) 
    username.grid(row=0, column=0, padx=10, pady=5)
    username_label = tk.Label(disable_user_window, text="Username:")
    username_label.grid(row=0, column=1, padx=10, pady=5)
    button_add_user = tk.Button(disable_user_window, text="disable User", command=lambda: disable_user(username.get(), sudo_password))
    button_add_user.grid(row=1, column=0, columnspan=2, padx=10, pady=5)

def disable_user(username,sudo_password):
   
    if not username:
        messagebox.showerror("Error", "Please enter a username.")
        return
    
    try:
        if sudo_password:
            sudo_command = f"sudo -S usermod -L {username}"
            process = subprocess.Popen(sudo_command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            process.communicate(input=sudo_password.encode())
            process.wait()
        else:
            subprocess.run(['sudo', 'usermod', '-L', username], check=True)
        
        if process.returncode == 0:
            messagebox.showinfo("Success", f"User '{username}' disabled successfully.")
        else:
            messagebox.showerror("Error", f"Failed to disable user '{username}'.")
    except subprocess.CalledProcessError as e:
        messagebox.showerror("Error", f"Failed to disable user: {e}")
    except Exception as e:
        messagebox.showerror("Error", f"An unexpected error occurred: {e}")

# Function to enable a user account 
def enab(sudo_password):
    enable_user_window = tk.Toplevel(root)
    enable_user_window.title("disable User")
    # Adjust window size
    enable_user_window.geometry('500x200') 
    username = tk.Entry(enable_user_window) 
    username.grid(row=0, column=0, padx=10, pady=5)
    username_label = tk.Label(enable_user_window, text="Username:")
    username_label.grid(row=0, column=1, padx=10, pady=5)
    button_add_user = tk.Button(enable_user_window, text="enable User", command=lambda: enable_user(username.get(), sudo_password))
    button_add_user.grid(row=1, column=0, columnspan=2, padx=10, pady=5)
def enable_user(username, sudo_password):
    if not username:
        messagebox.showerror("Error", "Please enter a username.")
        return
    
    try:
        if sudo_password:
            sudo_command = f"sudo -S usermod -U {username}"
            process = subprocess.Popen(sudo_command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            process.communicate(input=sudo_password.encode())
            process.wait()
        else:
            subprocess.run(['sudo', 'usermod', '-U', username], check=True)
        
        if process.returncode == 0:
            messagebox.showinfo("Success", f"User '{username}' enabled successfully.")
        else:
            messagebox.showerror("Error", f"Failed to enable user '{username}'.")
    except subprocess.CalledProcessError as e:
        messagebox.showerror("Error", f"Failed to enable user: {e}")
    except Exception as e:
        messagebox.showerror("Error", f"An unexpected error occurred: {e}")

# Function to change user password
def passne(sudo_password):
    ch_passwd_win = tk.Toplevel(root)
    ch_passwd_win.title("change User password")
    # Adjust window size
    ch_passwd_win.geometry('500x200') 
    username_entry = tk.Entry(ch_passwd_win)
    username_entry.grid(row=0, column=0, padx=10, pady=5)
    username_label = tk.Label(ch_passwd_win, text="Username:")
    username_label.grid(row=0, column=1, padx=10, pady=5)

     
    new_password_entry = tk.Entry(ch_passwd_win, show="*")
    new_password_entry.grid(row=3, column=0, padx=10, pady=5)
    new_password_label = tk.Label(ch_passwd_win, text="New Password:")
    new_password_label.grid(row=3, column=1, padx=10, pady=5)
    button_change_password = tk.Button(ch_passwd_win, text="Change Password", command=lambda: change_password(username_entry.get(), new_password_entry.get(),sudo_password))
    button_change_password.grid(row=4, column=0, columnspan=2, padx=10, pady=5)
def change_password(username, new_password, sudo_password):
    if not (username and new_password):
        messagebox.showerror("Error", "Please enter both username and new password.")
        return
    
    try:
        if sudo_password:
            sudo_command = f"sudo -S passwd {username}"
            passwd_process = subprocess.Popen(sudo_command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            passwd_process.communicate(input=f"{new_password}\n{new_password}\n{sudo_password}\n".encode())
            passwd_process.wait()
        else:
            passwd_process = subprocess.Popen(['sudo', 'passwd', username], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            passwd_process.communicate(input=f"{new_password}\n{new_password}\n".encode())
            passwd_process.wait()
            
        if passwd_process.returncode == 0:
            messagebox.showinfo("Success", f"Password for user '{username}' changed successfully.")
        else:
            messagebox.showerror("Error", "Failed to change password.")
    except Exception as e:
        messagebox.showerror("Error", f"An unexpected error occurred: {e}")
# Function to go back to the main menu
def back_to_main_menu(current_window):
    current_window.destroy()
    root.deiconify()

# Main tkinter window
root = tk.Tk()
root.geometry('600x200')  # Width x Height in pixels
root.title("Main Menu")

# Adjust window size
root.geometry('500x200')  # Width x Height in pixels

# Sudo password entry
label_sudo_password = tk.Label(root, text="Enter sudo password:", font=('Arial', 12))
label_sudo_password.grid(row=0, column=0, padx=10, pady=10)
sudo_password_entry = tk.Entry(root, show="*", font=('Arial', 12))
sudo_password_entry.grid(row=0, column=1, padx=10, pady=10)

# Buttons for user management
button_user_menu = tk.Button(root, text="User Management", command=lambda: open_user_management(root), font=('Arial', 14), width=20, height=2)
button_user_menu.grid(row=1, column=0, padx=10, pady=10)

# Buttons for group management
button_group_menu = tk.Button(root, text="Group Management", command=lambda: open_group_management(root), font=('Arial', 14), width=20, height=2)
button_group_menu.grid(row=1, column=1, padx=10, pady=10)

button_About_menu = tk.Button(root, text="About", command=lambda: about(), font=('Arial', 14), width=20, height=2)
button_About_menu.grid(row=2, column=0,columnspan=2, padx=10, pady=10)

# Function to open user management menu
def open_user_management(parent):
    parent.withdraw()  # Hide main menu
    user_management_window = tk.Toplevel()
    user_management_window.title("User Management")
    user_management_window.geometry("600x200")
    # Buttons for user management
    button_add_user = tk.Button(user_management_window, text="Add User", command=lambda: add_user(sudo_password_entry.get()), font=('Arial', 15))
    button_add_user.grid(row=1, column=0, padx=10, pady=5)

    button_modify_user = tk.Button(user_management_window, text="Modify User", command=lambda: open_modify_user_window(sudo_password_entry.get()), font=('Arial', 15))
    button_modify_user.grid(row=1, column=1, padx=10, pady=5)

    button_delete_user = tk.Button(user_management_window, text="Delete User", command=lambda: open_delete_user_window(sudo_password_entry.get()), font=('Arial', 15))
    button_delete_user.grid(row=1, column=2, padx=10, pady=5)

    button_list_users = tk.Button(user_management_window, text="List Users", command=open_list_users_window, font=('Arial', 15))
    button_list_users.grid(row=1, column=3, padx=10, pady=5)
    # Buttons for user management
    button_disable_user = tk.Button(user_management_window, text="Disable User", command=lambda: dis(sudo_password_entry.get()))
    button_disable_user.grid(row=2, column=0, padx=10, pady=5)

    button_enable_user = tk.Button(user_management_window, text="Enable User", command=lambda: enab(sudo_password_entry.get()))
    button_enable_user.grid(row=2, column=1, padx=10, pady=5)
    button_chanpasswd = tk.Button(user_management_window, text="change passwd", command=lambda: passne(sudo_password_entry.get()))
    button_chanpasswd.grid(row=2, column=2, padx=10, pady=5)
    button_back = tk.Button(user_management_window, text="Back to Main Menu", command=lambda: back_to_main_menu(user_management_window), font=('Arial', 15))
    button_back.grid(row=3, column=0, columnspan=2, padx=10, pady=5)

# Function to open group management menu
def open_group_management(parent):
    parent.withdraw()  # Hide main menu
    group_management_window = tk.Toplevel()
    group_management_window.title("Group Management")
    group_management_window.geometry('700x200') 
    # Buttons for group management
    button_add_group = tk.Button(group_management_window, text="Add Group", command=lambda: add_group(sudo_password_entry.get()), font=('Arial', 15))
    button_add_group.grid(row=2, column=0, padx=10, pady=5)

    button_modify_group = tk.Button(group_management_window, text="Modify Group", command=lambda: modify_group(sudo_password_entry.get()), font=('Arial', 15))
    button_modify_group.grid(row=2, column=1, padx=10, pady=5)

    button_delete_group = tk.Button(group_management_window, text="Delete Group", command=lambda: delete_group(sudo_password_entry.get()), font=('Arial', 15))
    button_delete_group.grid(row=2, column=2, padx=10, pady=5)

    button_list_groups = tk.Button(group_management_window, text="List Groups", command=open_list_groups_window, font=('Arial', 15))
    button_list_groups.grid(row=2, column=3,columnspan=2, padx=10, pady=5)


    button_back = tk.Button(group_management_window, text="Back to Main Menu", command=lambda: back_to_main_menu(group_management_window), font=('Arial', 15))
    button_back.grid(row=3, column=0, padx=10, pady=5)

# Start the Tkinter main loop
root.mainloop()